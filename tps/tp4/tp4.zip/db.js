//CONEXIÓN CON LA BASE DE DATOS 
import mysql from "mysql2/promise";  

export const conn = await mysql.createConnection({
    host : "localhost", 
    user : "root",
    password : "rootroot",
    database : "spoticfy"
});